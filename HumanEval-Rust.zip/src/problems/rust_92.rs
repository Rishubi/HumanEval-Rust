use std::any::Any;

/// Create a function that takes 3 numbers.
/// Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
/// Returns false in any other cases.
/// Examples
/// ```
/// assert_eq!(any_int(&5, &2, &7), true);
/// assert_eq!(any_int(&3, &2, &2), false);
/// assert_eq!(any_int(&3, &-2, &1), true);
/// assert_eq!(any_int(&3.6, &-2.2, &2), false);
/// ```
fn any_int(x: &dyn Any, y: &dyn Any, z: &dyn Any) -> bool {
    if let Some(&_x) = x.downcast_ref::<i32>() {
        if let Some(&_y) = y.downcast_ref::<i32>() {
            if let Some(&_z) = z.downcast_ref::<i32>() {
                if _x + _y == _z || _x + _z == _y || _y + _z == _x {
                    return true
                }
            }
        }
    }
    return false;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_92() {
        assert_eq!(any_int(&2, &3, &1), true);
        assert_eq!(any_int(&2.5, &2, &3), false);
        assert_eq!(any_int(&1.5, &5, &3.5), false);
        assert_eq!(any_int(&2, &6, &2), false);
        assert_eq!(any_int(&4, &2, &2), true);
        assert_eq!(any_int(&2.2, &2.2, &2.2), false);
        assert_eq!(any_int(&-4, &6, &2), true);
        assert_eq!(any_int(&2, &1, &1), true);
        assert_eq!(any_int(&3, &4, &7), true);
        assert_eq!(any_int(&3.0, &4, &7), false);
    }
}
