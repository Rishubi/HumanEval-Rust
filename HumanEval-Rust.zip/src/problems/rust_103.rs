/// You are given two positive integers n and m, and your task is to compute the
/// average of the integers from n through m (including n and m).
/// Round the answer to the nearest integer and convert that to binary.
/// If n is greater than m, return -1.
/// Example:
/// ```
/// assert_eq!(rounded_avg(1, 5), Ok("11"));
/// assert_eq!(rounded_avg(7, 5), Err(-1));
/// assert_eq!(rounded_avg(10, 20), Ok("1111"));
/// assert_eq!(rounded_avg(20, 33), Ok("11011"));
/// ```
fn rounded_avg(n: i32, m: i32) -> Result<String, i32> {
    if m < n {
        return Err(-1);
    }
    let summation = ((n..(m + 1)).sum::<i32>() as f64 / (m - n + 1) as f64).round() as i32;
    return Ok(format!("{:b}", summation));
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_103() {
        assert_eq!(rounded_avg(1, 5), Ok("11".to_string()));
        assert_eq!(rounded_avg(7, 13), Ok("1010".to_string()));
        assert_eq!(rounded_avg(964,977), Ok("1111001011".to_string()));
        assert_eq!(rounded_avg(996,997), Ok("1111100101".to_string()));
        assert_eq!(rounded_avg(560,851), Ok("1011000010".to_string()));
        assert_eq!(rounded_avg(185,546), Ok("101101110".to_string()));
        assert_eq!(rounded_avg(362,496), Ok("110101101".to_string()));
        assert_eq!(rounded_avg(350,902), Ok("1001110010".to_string()));
        assert_eq!(rounded_avg(197,233), Ok("11010111".to_string()));
        assert_eq!(rounded_avg(7, 5), Err(-1));
        assert_eq!(rounded_avg(5, 1), Err(-1));
        assert_eq!(rounded_avg(5, 5), Ok("101".to_string()));
    }
}