/// Given a list of numbers, return the sum of squares of the numbers
/// in the list that are odd. Ignore numbers that are negative or not integers.
///
/// double_the_difference([1, 3, 2, 0]) == 1 + 9 + 0 + 0 = 10
/// double_the_difference([-1, -2, 0]) == 0
/// double_the_difference([9, -2]) == 81
/// double_the_difference([0]) == 0
///
/// If the input list is empty, return 0.
fn double_the_difference(list: &Vec<f64>) -> usize {
    return list.iter().filter(|&&i| i > 0. && i % 2.0 != 0.0 && i.round() == i).map(|x| x * x).sum::<f64>() as usize;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_151() {
        assert_eq!(double_the_difference(&vec![]), 0);
        assert_eq!(double_the_difference(&vec![5., 4.]), 25);
        assert_eq!(double_the_difference(&vec![0.1, 0.2, 0.3]), 0);
        assert_eq!(double_the_difference(&vec![-10., -20., -30.]), 0);
        assert_eq!(double_the_difference(&vec![-1., -2., 8.]), 0);
        assert_eq!(double_the_difference(&vec![0.2, 3., 5.]), 34);
        let lst: Vec<i32> = (-99..100).step_by(2).collect();
        let odd_sum = lst.iter().filter(|&&i| i % 2 != 0 && i > 0).map(|&i| i * i).sum::<i32>() as usize;
        assert_eq!(double_the_difference(&lst.iter().map(|&i| i as f64).collect()), odd_sum);
    }
}