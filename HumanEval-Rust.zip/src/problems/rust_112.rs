/// We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
/// then check if the result string is palindrome.
/// A string is called palindrome if it reads the same backward as forward.
/// You should return a tuple containing the result string and true/false for the check.
/// Example
/// For s = "abcde", c = "ae", the result should be ("bcd", false)
/// For s = "abcdef", c = "b"  the result should be ("acdef", false)
/// For s = "abcdedcba", c = "ab", the result should be ("cdedc", true)
fn reverse_delete(s: String, c: String) -> (String, bool) {
    let str = s.chars().filter(|&char| !c.contains(char)).collect::<String>();
    let is_palindrome = str.chars().rev().collect::<String>() == str;
    return (str, is_palindrome);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_112() {
        assert_eq!(reverse_delete("abcde".to_string(), "ae".to_string()), ("bcd".to_string(), false));
        assert_eq!(reverse_delete("abcdef".to_string(),  "b".to_string()), ("acdef".to_string(), false));
        assert_eq!(reverse_delete("abcdedcba".to_string(), "ab".to_string()), ("cdedc".to_string(), true));
        assert_eq!(reverse_delete("dwik".to_string(), "w".to_string()), ("dik".to_string(), false));
        assert_eq!(reverse_delete("a".to_string(), "a".to_string()), ("".to_string(), true));
        assert_eq!(reverse_delete("abcdedcba".to_string(), "".to_string()), ("abcdedcba".to_string(), true));
        assert_eq!(reverse_delete("abcdedcba".to_string(), "v".to_string()), ("abcdedcba".to_string(), true));
        assert_eq!(reverse_delete("vabba".to_string(), "v".to_string()), ("abba".to_string(), true));
        assert_eq!(reverse_delete("mamma".to_string(),  "mia".to_string()), ("".to_string(), true));
    }
}