use std::any::Any;

/// Filter given list of any values only for integers
/// ```
/// assert_eq!(filter_integers(vec![&"a", &3.14, &5]), vec![5]);
/// assert_eq!(filter_integers(vec![&1, &2, &3, &"abc", &HashMap::<&dyn Any, &dyn Any>::new(), &Vec::<&dyn Any>::new()], vec![1, 2, 3]);
/// ```
pub fn filter_integers(values: &Vec<&dyn Any>) -> Vec<i32> {
    values.iter().filter_map(|x| x.downcast_ref().copied()).collect()
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;
    use super::*;

    #[test]
    fn test_22() {
        assert_eq!(filter_integers(&vec![]), vec![]);
        assert_eq!(filter_integers(&vec![&4, &HashMap::<&dyn Any, &dyn Any>::new(), &Vec::<&dyn Any>::new(), &23.2, &9, &"adasd"]), vec![4, 9]);
        assert_eq!(filter_integers(&vec![&3, &"c", &3, &3, &"a", &"b"]), vec![3, 3, 3])
    }
}