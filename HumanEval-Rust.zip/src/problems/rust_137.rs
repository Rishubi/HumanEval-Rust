use std::any::{Any, TypeId};

/// Create a function that takes integers, floats, or strings representing
/// real numbers, and returns the larger variable in its given variable type.
/// Return None if the values are equal.
/// Note: If a real number is represented as a string, the floating point might be . or ,
///
/// compare_one(1, 2.5) ➞ 2.5
/// compare_one(1, "2,3".to_string()) ➞ "2,3"
/// compare_one("5,1".to_string(), "6") ➞ "6"
/// compare_one("1".to_string(), 1) ➞ None
fn compare_one<'a>(a: &'a dyn Any, b: &'a dyn Any) -> Option<&'a dyn Any> {
    let temp_a = if a.type_id() == TypeId::of::<String>() {
        a.downcast_ref::<String>().cloned().unwrap().replace(",", ".")
    } else if a.type_id() == TypeId::of::<f64>() {
        a.downcast_ref::<f64>().copied().unwrap().to_string()
    } else if a.type_id() == TypeId::of::<i32>() {
        a.downcast_ref::<i32>().copied().unwrap().to_string()
    } else {
        return None
    };
    let temp_b = if b.type_id() == TypeId::of::<String>() {
        b.downcast_ref::<String>().cloned().unwrap().replace(",", ".")
    } else if b.type_id() == TypeId::of::<f64>() {
        b.downcast_ref::<f64>().copied().unwrap().to_string()
    } else if b.type_id() == TypeId::of::<i32>() {
        b.downcast_ref::<i32>().copied().unwrap().to_string()
    } else {
        return None
    };
    if temp_a.parse::<f64>().unwrap() == temp_b.parse::<f64>().unwrap() {
        return None;
    }
    if temp_a.parse::<f64>().unwrap() > temp_b.parse::<f64>().unwrap() {
        return Some(a.clone());
    } else {
        return Some(b.clone());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_137() {
        assert_eq!(compare_one(&1, &2).unwrap().downcast_ref::<i32>().unwrap(), &2);
        assert_eq!(compare_one(&1, &2.5).unwrap().downcast_ref::<f64>().unwrap(), &2.5);
        assert_eq!(compare_one(&2, &3).unwrap().downcast_ref::<i32>().unwrap(), &3);
        assert_eq!(compare_one(&5, &6).unwrap().downcast_ref::<i32>().unwrap(), &6);
        assert_eq!(compare_one(&1, &"2,3".to_string()).unwrap().downcast_ref::<String>().unwrap(), &"2,3");
        assert_eq!(compare_one(&"5,1".to_string(), &"6".to_string()).unwrap().downcast_ref::<String>().unwrap(), &"6");
        assert_eq!(compare_one(&"1".to_string(), &"2".to_string()).unwrap().downcast_ref::<String>().unwrap(), &"2");
        assert_eq!(compare_one(&"1".to_string(), &1).is_none(), true);
    }
}