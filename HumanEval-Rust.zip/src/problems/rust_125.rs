enum ListOrNumber<'a> {
    List(Vec<&'a str>),
    Number(usize)
}

/// Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
/// should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
/// alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
/// Examples
/// split_words("Hello world!") ➞ ["Hello", "world!"]
/// split_words("Hello,world!") ➞ ["Hello", "world!"]
/// split_words("abcdef") == 3
fn split_words(txt: &str) -> ListOrNumber {
    if txt.contains(" ") {
        return ListOrNumber::List(txt.split(" ").collect());
    } else if txt.contains(",") {
        return ListOrNumber::List(txt.split(",").collect());
    } else {
        return ListOrNumber::Number(txt.chars().filter(|&i| i.is_lowercase() && (i as usize) % 2 == 0).count());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_125() {
        match split_words("Hello world!") {
            ListOrNumber::List(list) => assert_eq!(list, vec!["Hello", "world!"]),
            _ => assert!(false)
        };
        match split_words("Hello,world!") {
            ListOrNumber::List(list) => assert_eq!(list, vec!["Hello", "world!"]),
            _ => assert!(false)
        };
        match split_words("Hello world,!") {
            ListOrNumber::List(list) => assert_eq!(list, vec!["Hello", "world,!"]),
            _ => assert!(false)
        };
        match split_words("Hello,Hello,world !") {
            ListOrNumber::List(list) => assert_eq!(list, vec!["Hello,Hello,world", "!"]),
            _ => assert!(false)
        };
        match split_words("abcdef") {
            ListOrNumber::Number(number) => assert_eq!(number, 3),
            _ => assert!(false)
        };
        match split_words("aaabb") {
            ListOrNumber::Number(number) => assert_eq!(number, 2),
            _ => assert!(false)
        };
        match split_words("aaaBb") {
            ListOrNumber::Number(number) => assert_eq!(number, 1),
            _ => assert!(false)
        };
        match split_words("") {
            ListOrNumber::Number(number) => assert_eq!(number, 0),
            _ => assert!(false)
        };
    }
}