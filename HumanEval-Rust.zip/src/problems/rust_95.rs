use std::any::Any;

/// Given a list, return true if all elements are strings in lower
/// case or all elements are strings in upper case, else return false.
/// The function should return false is the given list is empty.
/// Examples:
/// check_dict_case(["a", "b"]) should return true.
/// check_dict_case(["a", "A", "B"]) should return false.
/// check_dict_case(["a", 8, "a"]) should return false.
/// check_dict_case(["Name", "Age", "City"]) should return false.
/// check_dict_case(["STATE", "ZIP"]) should return true.
fn check_dict_case(dict: &Vec<&dyn Any>) -> bool {
    if dict.is_empty() {
        return false;
    } else {
        let mut state = "start";
        for key in dict.iter() {
            match key.downcast_ref::<&str>() {
                Some(_key) => {
                    if state == "start" {
                        if !_key.chars().any(|c| c.is_lowercase()) {
                            state = "upper";
                        } else if !_key.chars().any(|c| c.is_uppercase()) {
                            state = "lower";
                        } else {
                            break;
                        }
                    } else if (state == "upper" && _key.chars().any(|c| c.is_lowercase())) || (state == "lower" && _key.chars().any(|c| c.is_uppercase())) {
                        state = "mixed";
                        break;
                    } else {
                        break;
                    }
                },
                None => {
                    state = "mixed";
                    break;
                }
            }
        }
        return state == "upper" || state == "lower";
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_95() {
        assert_eq!(check_dict_case(&vec![&"p", &"b"]), true);
        assert_eq!(check_dict_case(&vec![&"p", &"A", &"B"]), false);
        assert_eq!(check_dict_case(&vec![&"p", &5, &"a"]), false);
        assert_eq!(check_dict_case(&vec![&"Name", &"Age", &"City"]), false);
        assert_eq!(check_dict_case(&vec![&"STATE", &"ZIP"]), true);
        assert_eq!(check_dict_case(&vec![&"fruit", &"taste"]), true);
        assert_eq!(check_dict_case(&vec![]), false);
    }
}