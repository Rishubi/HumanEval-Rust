mod problems;

pub use problems::*;
fn main() {
    let txt = "abc";
    println!("{}", txt.chars().filter(|i| i.is_lowercase() && (i as usize) % 2 == 0).count());
}